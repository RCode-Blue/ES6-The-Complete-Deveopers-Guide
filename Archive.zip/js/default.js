console.log(`test`);
/*
Weekxx Dayxx Homework | Classwork
URL:

*/

/*
Task:

*/
